Dynamic
=========

Moodle theme.

Dynamic is a fluid-width, three-column theme for Moodle 2.x. It makes use of 
sections on the main page, giving it a website type look for greater accessibility.
It comes in bright and fresh colors and has a lower contrast interface to maintain visibility.
It also includes a basic settings page allowing you to change your logo, tag line with 
the option to hide tagline, footer text and custom CSS.

Customization using custom theme settings
-----------------------------------------
The settings page for the Dynamic theme can be located by navigating to:
Administration > Site Administration > Appearance > Themes > Dynamic

Theme documentation
--------------------
Further information can be found on 3i Logic website.
http://3ilogic.com/plugindoc/Dynamic.pdf