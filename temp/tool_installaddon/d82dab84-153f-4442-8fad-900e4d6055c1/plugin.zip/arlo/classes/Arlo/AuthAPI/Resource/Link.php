<?php

namespace enrol_arlo\Arlo\AuthAPI\Resource;

/**
 * Class Link
 * @package enrol_arlo\Arlo\AuthAPI\Resource
 */
class Link {
    public $rel;
    public $type;
    public $title;
    public $href;
}
