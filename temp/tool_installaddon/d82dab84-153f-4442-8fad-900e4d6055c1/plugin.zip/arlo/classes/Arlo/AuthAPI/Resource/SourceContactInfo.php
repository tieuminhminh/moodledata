<?php

namespace enrol_arlo\Arlo\AuthAPI\Resource;

/**
 * Class SourceContactInfo
 * @package enrol_arlo\Arlo\AuthAPI\Resource
 */
class SourceContactInfo extends ContactInfo {}
