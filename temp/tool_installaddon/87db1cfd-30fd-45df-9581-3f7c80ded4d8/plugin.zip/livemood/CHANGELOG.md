##Live-School Moodle Plugin Change Log

17.0.9 (2018102317)
 * Minor bugs fixed
